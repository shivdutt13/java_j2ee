package com.spring;

/**
 * 
 * @author DELL
 *  This class for calculating factorial of 
 *  a number.
 */
public class Factorial {
	private int sum=1;
	private int num;

	public Factorial(int num) {
		super();
		this.num = num;
	}
	
	public int  calFact(){
 	    for(int i=2;i<=num;i++){
        	sum=sum*i;
        }
		return sum;
	}
	
}
