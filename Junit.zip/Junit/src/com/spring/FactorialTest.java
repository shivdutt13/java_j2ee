/**
 * 
 */
package com.spring;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author DELL
 *
 */
public class FactorialTest {
	
	static Factorial factorial;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	    //this method will execute only time when class is loaded
		//here we can write code which will execute only once during life cycle of
		//Junit
		//init
		factorial=new Factorial(5);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	    //here will write code for clean up for the resource
		//destroy
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	   //this method will call before calling each test case.
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	     //this method will be called after executing each and every test cases
	}

	/**
	 * Test method for {@link com.spring.Factorial#calFact()}.
	 */
	@Test
	public void testCalFact() {
         int num=factorial.calFact();		
         assertEquals("fact cannot be zero",true,num>0);
         assertEquals("Factorial result is not correct.",120,num);
    }

}
