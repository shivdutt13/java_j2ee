package com.shopping.cart.hibernate.dao;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * Dao Test Class for Screen Book Category
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(inheritLocations = true, locations = { "classpath*:test-spring-hibernate-integration.xml" })
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class BookCategoryDaoImplTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPersistBookCategory() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateBookCategory() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewBookCategoryInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAllBookCategory() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewBookCategoryString() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteBookCategoryById() {
		fail("Not yet implemented");
	}

}
