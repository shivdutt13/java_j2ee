package com.spring.book.action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.cart.hibernate.dao.BookCategoryDao;
import com.shopping.cart.jdbc.model.Book;
import com.shopping.cart.jdbc.model.BookCategory;
import com.shopping.cart.spring.jdbc.dao.SpringJdbcDao;


@Controller
public class BookController {
	
	@Autowired
	@Qualifier("springJdbcDaoImpl")
	private SpringJdbcDao springJdbcDao;
	
	
	@Autowired
	@Qualifier("bookCategoryDaoImpl")
	private BookCategoryDao bookCategoryDao;
	
	
	@ModelAttribute("bookCotegoryList") 
	public List<BookCategory> populateCountryList() { 
	  return  bookCategoryDao.findAllBookCategory();
	} 
	
	@RequestMapping(value="addBook.do",method = RequestMethod.GET)
	public String persistBook(ModelMap model){
		Book book = new Book(); 
		model.addAttribute("book",book);
		//bookForm.jsp
		return "bookForm"; 
	}
	
	
	@RequestMapping(value="addBook.do",method = RequestMethod.POST)
	public String onSubmit(@ModelAttribute("book") Book book) { 
	    //if(book.getBookId()==null)
		book.setAquantity(book.getQuantity());
		springJdbcDao.persistBook(book);
	    //else{
	    	//springJdbcDao.updateBook(book);
		    	
	    //}
	  return "bookForm"; 
	
	}
	
	@RequestMapping(value="editBook.do",method = RequestMethod.POST)
	public String editBook(@ModelAttribute("book") Book book) { 
		springJdbcDao.updateBook(book);
	      return "customerHome"; 
	
	}
	
	
	@RequestMapping(value="editBook.do",method = RequestMethod.GET)
	public String editBook(@RequestParam("bookId") String bookId,ModelMap model) { 
	  Book book=springJdbcDao.viewBook(bookId);
	  model.addAttribute("book",book);
		//bookForm.jsp
	  return "editBookForm"; 
	
	}
	
	@RequestMapping("/showBooks.do")
	public ModelAndView findAllBooks() { 
	  ModelAndView modelAndView=new ModelAndView("showAllBooks");
	   List<Book> books=springJdbcDao.findAllBook();
	   modelAndView.addObject("books",books);
	  return modelAndView; 
	
	} 



}
