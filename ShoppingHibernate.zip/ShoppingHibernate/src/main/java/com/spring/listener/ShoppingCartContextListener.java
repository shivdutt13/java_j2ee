package com.spring.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * 
 * @author nagendra.yadav This is listener which will be used to track all the
 *         functionality at the time of starting the application and stopping
 *         the application
 * 
 */
public class ShoppingCartContextListener implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
	    
		System.out.println("#################__INIT()___############");
		arg0.getServletContext().setAttribute("email", "nagendra.yadav.niit@gmail.com");
		//arg0.getServletContext().setAttribute("strLists",allowPages);
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		System.out.println("#################__Destroy()___############");
	}
}
