package com.spring.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.shopping.cart.hibernate.model.LoginForm;
import com.spring.constant.ApplicationConstant;

/**
 * 
 * @author nagendra.yadav
 * This is listener which helps to track logged in user  
 *
 */
public class ShoppingSessionListener implements  HttpSessionListener{

	@Override
	public void sessionCreated(HttpSessionEvent arg0) {
	  //Here we can log "login time" for logged in user 
	  //into the System(Application).	
		HttpSession session=arg0.getSession();
		LoginForm loginForm=(LoginForm)session.getAttribute(ApplicationConstant.USER_SESSION);
		String uname="unknown";
		if(loginForm!=null){
			uname=loginForm.getLogin();
		}
		System.out.println("Session is created for user = "+uname);		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
	  //Here we have to track user's logout time.
	  //current time - session time out time = the time when user was logged out last time.
	  //now we can write query to logged in "last logout time"	for user.
		HttpSession session=arg0.getSession();
		LoginForm loginForm=(LoginForm)session.getAttribute(ApplicationConstant.USER_SESSION);
		String uname="unknown";
		if(loginForm!=null){
			uname=loginForm.getLogin();
		}
		System.out.println("Session is destroy for user = "+uname);
	}

}
