package com.spring.action.filter;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.shopping.cart.hibernate.model.LoginForm;
import com.spring.constant.ApplicationConstant;

/**
 * Access filter class
 * nagendra.yadav
 */
public class ShoppingFilter implements Filter {

	@SuppressWarnings("unused")
	private Set<String> searchAllowPages;
	/**
	 * Method init.
	 * @param config
	 * @throws javax.servlet.ServletException
	 */
	public void init(FilterConfig config) throws ServletException {
        searchAllowPages=new HashSet<String>();
		String strList=config.getServletContext().getInitParameter("allowPages");
		String strToken[]=strList.split(",");
		for(String param : strToken){
			searchAllowPages.add(param);
		}
	}
	
	public void destroy() {
	}

	/**
	 * @param FilterChain is used to call another filter
	 * @param req
	 * @param resp
	 */
	
	
	
    //http://localhost:8080/ShoppingHibernate/login.do
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws ServletException, IOException {

		//  /login.do=getServletPath()
		String action = ((HttpServletRequest) req).getServletPath().substring(1);
		//action=login.do
	    // action string with delimiters
        System.out.println("******************************"+action);
        
     	if(searchAllowPages.contains(action)){
			//Do not block the request for above requests
     		//call other filter if filter exists or call requested resource
     		chain.doFilter(req, resp);
		}else{

			
		//Give me session if session is already there otherwise return null	
		HttpSession session=((HttpServletRequest)req).getSession(false);
		System.out.println("*****ISNIDE THE ELSE"+action);

        if(session!=null &&  session.getAttribute(ApplicationConstant.USER_SESSION)!=null && ((LoginForm)session.getAttribute(ApplicationConstant.USER_SESSION)).getLogin()!=null){
        	
        	//Do not block the request for above requests
     		//call other filter if filter exists or call requested resource
     	     System.out.println("*****ISNIDE THE SESSION"+action);
			 chain.doFilter(req, resp);
    	}else{
			System.out.println("FILTER________________________");
			req.setAttribute("errorMsg","Session time out,Please login again!");
			RequestDispatcher rd=((HttpServletRequest)req).getRequestDispatcher("login.jsp");
			rd.forward(req,resp);
		}
			/////modifying the response here######################
			System.out.println("AT LAST");
	}
	}

	


}



