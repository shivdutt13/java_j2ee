package com.spring.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.cart.hibernate.dao.ShoppingCardDao;
import com.shopping.cart.hibernate.model.Customer;
import com.shopping.cart.hibernate.model.LoginForm;
import com.spring.constant.ApplicationConstant;

@Controller
public class CustomerController {

	@Autowired
	@Qualifier("shoppingCardDaoImplProxy")
	private ShoppingCardDao shoppingCartDao;
	
	//@Autowired
//	@Qualifier("shoppingCardDaoImpl")
	//private ShoppingCardDao shoppingCartDao;
	
	
	@RequestMapping("/customerRegistration.do")
	//@RequestParam annotation binds jsp/html component 
	//with parameter of method name of 
	//@RequestParam binds form input parameter to the method argument
	//controller
	public ModelAndView registerCustomer(@RequestParam("firstName") String firstName,
			@RequestParam("lastName") String lastName,
			@RequestParam("address") String address,
			@RequestParam("email") String email,
			@RequestParam("mobile") String mobile,
			@RequestParam("age") String age,
			@RequestParam("dob") String dob,
			@RequestParam("ssn") String ssn,
			@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam("role") String role,
			@RequestParam("gender") String gender	
	) {
		
		//logic for checking role
		//System.out.println("I am inside ="+"method registerCustomer");
		ModelAndView modelAndView = new ModelAndView("loginsuccess");
		Customer customer = new Customer();
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setAddress(address);
		customer.setEmail(email);
		if(age!=null)
		customer.setAge(Integer.parseInt(age));
		
		customer.setDob(dob);
		customer.setMobile(mobile);
		customer.setSsn(ssn);
		customer.setUsername(username);
		customer.setPassword(password);
		customer.setRole(role);
		customer.setGender(gender);
		shoppingCartDao.registerCustomer(customer);
		
			modelAndView.addObject("msg","Customer is registered successfully!");
		
		return modelAndView;
	}
	
	
	@RequestMapping("/updateCustomer.do")
	//@RequestParam annotation binds jsp/html component 
	//with parameter of method name of 
	//controller
	public ModelAndView updateCustomer(HttpServletRequest request,@RequestParam("firstName") String firstName,
			@RequestParam("lastName") String lastName,
			@RequestParam("address") String address,
			@RequestParam("email") String email,
			@RequestParam("mobile") String mobile,
			@RequestParam("age") String age,
			@RequestParam("dob") String dob,
			@RequestParam("ssn") String ssn,
			@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam("role") String role,
			@RequestParam("gender") String gender	
	) {
		//System.out.println("I am inside ="+"method updateCustomer");
		ModelAndView modelAndView = new ModelAndView("customerHome");
		Customer customer = new Customer();
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setAddress(address);
		customer.setEmail(email);
		if(age!=null)
		customer.setAge(Integer.parseInt(age));
		customer.setDob(dob);
		customer.setMobile(mobile);
		customer.setSsn(ssn);
		customer.setUsername(username);
		customer.setPassword(password);
		customer.setRole(role);
		customer.setGender(gender);
		
		  HttpSession session=request.getSession();
		    LoginForm loginForm=(LoginForm)session.getAttribute(ApplicationConstant.USER_SESSION);
		    int userid=loginForm.getId();
		 
		customer.setId(userid);
		
		shoppingCartDao.updateCustomer(customer);
		modelAndView.addObject("showMsg","Your data has been updated succesfully");
		return modelAndView;
	}
	
	
	@RequestMapping("/editCustomer.do")
	public ModelAndView editCustomer(HttpServletRequest request) {
		//System.out.println("I am inside ="+"method editCustomer");
		
		    HttpSession session=request.getSession();
		    LoginForm loginForm=(LoginForm)session.getAttribute(ApplicationConstant.USER_SESSION);
		    int userid=loginForm.getId();
		    Customer customer=shoppingCartDao.findCustomerById(userid);
		    customer.setUsername(loginForm.getLogin());
		    customer.setPassword(loginForm.getPassword());
		    customer.setRole(loginForm.getRole());
		    
		    //It means View Resolver will not come into the picture 
		    ModelAndView modelAndView=new ModelAndView("updateRegistration");
			modelAndView.addObject("customer",customer);
		
		return modelAndView;
	}
	
	//showcustomerRegistration.do =>CustomerController(method=editCustomer)
	
	@RequestMapping(value="/showcustomerRegistration.do",method=RequestMethod.GET)
	public ModelAndView editCustomer() {
		ModelAndView modelAndView=new ModelAndView("customerRegistration");
		return modelAndView;
	}
	
	@RequestMapping("/showAllCustomer.do")
	public String getAllCustomer(ModelMap model){
		model.addAttribute("customers", shoppingCartDao.findAllCustomer()); 
		return "showAllCustomer";
	}
}
