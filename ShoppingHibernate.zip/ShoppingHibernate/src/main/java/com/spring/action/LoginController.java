package com.spring.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.cart.hibernate.dao.ShoppingCardDao;
import com.shopping.cart.hibernate.model.LoginForm;
import com.spring.constant.ApplicationConstant;

@Controller
public class LoginController {

	@Autowired
	@Qualifier("shoppingCardDaoImpl")
	private ShoppingCardDao shoppingCartDao;

	@RequestMapping("/validate.do")
	//@RequestParam annotation binds jsp/html component 
	//with parameter of method name of 
	//controller
	public ModelAndView validateUser(HttpServletRequest request, @RequestParam("username") String uname,
			@RequestParam("password") String ppassword) {
		
		ModelAndView modelAndView =new ModelAndView("login");

		LoginForm loginForm = new LoginForm();
		loginForm.setLogin(uname);
		loginForm.setPassword(ppassword);
		loginForm=shoppingCartDao.validateUser(loginForm);
		if(loginForm==null){
			modelAndView.addObject("msg","User does not exist!");
		}else{
			//creating user session
		  HttpSession session=request.getSession();
		  if(loginForm.getRole().equalsIgnoreCase(ApplicationConstant.CUSTOMER_ROLE)){
			  session.setAttribute(ApplicationConstant.USER_SESSION, loginForm);
			  modelAndView=new ModelAndView("customerHome");		
		  }else if(loginForm.getRole().equalsIgnoreCase(ApplicationConstant.ADMIN_ROLE)){
			  session.setAttribute("USER_SESSION", loginForm);
			  modelAndView=new ModelAndView("customerHome");		
		  }
		}
		return modelAndView;
	}

}
