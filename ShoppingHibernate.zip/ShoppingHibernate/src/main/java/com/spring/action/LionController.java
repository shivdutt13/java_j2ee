package com.spring.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.cart.hibernate.dao.ShoppingCardDao;
import com.shopping.cart.hibernate.model.Lion;

@Controller
public class LionController {
	
	@Autowired
	@Qualifier("shoppingCardDaoImpl")
	private ShoppingCardDao shoppingCartDao;
	
	@RequestMapping("/persist.do")
	public ModelAndView persistLion(){
		ModelAndView modelAndView=new ModelAndView("success");		
		Lion lion=new Lion();
		lion.setName("KK");
		lion.setName("red");
		shoppingCartDao.dummy(lion);
		return modelAndView;
		
	}

}
