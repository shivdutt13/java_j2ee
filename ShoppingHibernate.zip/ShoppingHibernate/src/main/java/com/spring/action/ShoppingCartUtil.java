package com.spring.action;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * @author nagendra.yadav
 *  This is utility class which  
 */
public class ShoppingCartUtil {
	
	public static String getCurrentDate(){
   		  SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		  String txt=formatter.format(new Date());	
		  System.out.println("txt = "+txt);	   
          return txt; 
	}
	
	public static String formatDate(String format){
 		  SimpleDateFormat formatter = new SimpleDateFormat(format);
		  String txt=formatter.format(new Date());	
		  System.out.println("txt = "+txt);	   
        return txt; 
	}


}
