package com.spring.constant;

public interface ApplicationConstant {
	
	public static final String CUSTOMER_ROLE="customer";
	public static final String ADMIN_ROLE="admin";
	public static final String GUEST_ROLE="admin";
	
	public static final String USER_SESSION="USER_SESSION";
	

}
