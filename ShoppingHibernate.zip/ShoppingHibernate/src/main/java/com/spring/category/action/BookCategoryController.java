package com.spring.category.action;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.cart.hibernate.dao.BookCategoryDao;
import com.shopping.cart.jdbc.model.BookCategory;


@Controller
public class BookCategoryController {
	
	@Autowired
	@Qualifier("bookCategoryDaoImpl")
	private BookCategoryDao bookCategoryDao;
	
	
	@RequestMapping(value="addBookCategory.do",method = RequestMethod.GET)
	public String persistBookCategory(ModelMap model){
		BookCategory bookCategory = new BookCategory(); 
		model.addAttribute("bookCategory",bookCategory);
		//bookForm.jsp
		return "bookCategory"; 
	}
	
	
	@RequestMapping(value="addBookCategory.do",method = RequestMethod.POST)
	public String onSubmit(@ModelAttribute("bookCategory") BookCategory bookCategory) { 
	    //if(book.getBookId()==null)
		bookCategoryDao.persistBookCategory(bookCategory);
	    //else{
	    	//springJdbcDao.updateBook(book);
		    	
	    //}
	  return "customerHome"; 
	
	}
	
	@RequestMapping(value="editBookCategory.do",method = RequestMethod.POST)
	public String editBook(@ModelAttribute("bookCategory") BookCategory bookCategory) { 
		bookCategoryDao.updateBookCategory(bookCategory);
	     return "customerHome"; 
	
	}
	
	
	@RequestMapping(value="editBookCategory.do",method = RequestMethod.GET)
	public String editBook(@RequestParam("bookCategoryId") String bookCategoryId,ModelMap model) { 
		BookCategory bookCategory=bookCategoryDao.viewBookCategory(Integer.parseInt(bookCategoryId));
	  model.addAttribute("bookCategory",bookCategory);
		//bookForm.jsp
	  return "editBookCategory"; 
	
	}
	
	@RequestMapping("/showBookCategory.do")
	public ModelAndView findAllBooksCategory() { 
	  ModelAndView modelAndView=new ModelAndView("showAllBooksCategory");
	   List<BookCategory> booksCategory=bookCategoryDao.findAllBookCategory();
	   modelAndView.addObject("booksCategory",booksCategory);
	  return modelAndView; 
	
	} 

}
