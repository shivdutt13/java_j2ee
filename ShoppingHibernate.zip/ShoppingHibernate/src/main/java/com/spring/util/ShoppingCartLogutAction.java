package com.spring.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;


/**
 * 
 * @author nagendra.yadav
 * This is controller for shopping cart and will called when
 * user will click on log out button into the application
 *
 */
@Controller
public class ShoppingCartLogutAction {

	public String logout(HttpServletRequest request){
        //retrieving the existing Session for logged in user into the application 
		HttpSession session=request.getSession(false);
		//we can write query here to logged , logout time for the user.
		if(session!=null){
			session.invalidate();
		}
		return "redirect:login.jsp";
	}
}
