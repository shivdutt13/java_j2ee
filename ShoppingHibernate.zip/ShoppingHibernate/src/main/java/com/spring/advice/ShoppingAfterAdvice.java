package com.spring.advice;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.stereotype.Component;

/**
 * 
 * @author nagendra.yadav
 *
 */
@Component
public class ShoppingAfterAdvice  implements AfterReturningAdvice{
	//arg0 contains return data for called method
	//arg1 contains method info which has to be called after this
//	/arg2 contains method parameters which has to be called after this
	//arg3 object reference which contains the method to be called

	@Override
	public void afterReturning(Object arg0, Method arg1, Object[] arg2,
			Object arg3) throws Throwable {
		try {
		   System.out.println("____THIS IS EXECUTED AFTER RETURNING THE VALUE FOR METHOD ="+arg1.getName());
		}catch (IllegalArgumentException e) {
			System.out.println("HijackAroundMethod : Throw exception hijacked!");
			throw e;
		}
		
	}

}
