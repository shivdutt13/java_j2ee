package com.spring.advice;

import org.springframework.aop.ThrowsAdvice;
import org.springframework.stereotype.Component;

@Component
//This advice will come into the picture when IllegalArgumentException or
//it's sub class type of exception will be thrown inside the cross cut object.
public class ShoppingThrowAdvice implements ThrowsAdvice{
	
	public void afterThrowing(IllegalArgumentException e) throws Throwable {
		System.out.println("HijackThrowException : Throw exception hijacked!");
	 }	

}
