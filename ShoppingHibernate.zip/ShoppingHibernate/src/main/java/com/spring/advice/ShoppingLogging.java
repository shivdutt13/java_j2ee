package com.spring.advice;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.stereotype.Component;

import com.shopping.cart.hibernate.model.Customer;

/**
 * 
 * @author nagendra.yadav
 * This is advice 
 */
@Component
public class ShoppingLogging implements MethodBeforeAdvice, AfterReturningAdvice{

	//arg0 contains method info which has to be called after this
//	/arg1 contains method parameters which has to be called after this
	//arg2 object reference which contains the method to be called 
	@Override
	public void before(Method arg0, Object[] arg1, Object arg2)
			throws Throwable {
		System.out.println("#######Inside the method = "+arg0.getName()+"########");
		
	}
	
	@Override
	public void afterReturning(Object arg0, Method arg1, Object[] arg2,
			Object arg3) throws Throwable {
		System.out.println("____THIS IS EXECUTED AFTER RETURNING THE VALUE FOR METHOD ="+arg1.getName());
		if(arg0 instanceof Customer){
			Customer customer=(Customer)arg0;
			System.out.println("customer email ="+customer.getEmail());
		}
		
	}
	

}
