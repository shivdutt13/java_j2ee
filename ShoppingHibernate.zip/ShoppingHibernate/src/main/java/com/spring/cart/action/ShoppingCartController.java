package com.spring.cart.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shopping.cart.hibernate.dao.BookCategoryDao;
import com.shopping.cart.hibernate.dao.ShoppingCardDao;
import com.shopping.cart.jdbc.model.Book;
import com.shopping.cart.jdbc.model.BookCategory;
import com.shopping.cart.jdbc.model.BookSearchCriteria;
import com.shopping.cart.jdbc.model.CheckoutItem;

@Controller
public class ShoppingCartController {

	@Autowired
	@Qualifier("bookCategoryDaoImpl")
	private BookCategoryDao bookCategoryDao;
	
	@Autowired
	@Qualifier("shoppingCardDaoImplProxy")
	private ShoppingCardDao shoppingCartDao;
	
	@ModelAttribute("bookCotegoryList") 
	public List<BookCategory> populateCountryList() { 
	  return  bookCategoryDao.findAllBookCategory();
	} 
	
	@RequestMapping(value="searchPage.do",method = RequestMethod.GET)
	public String searchPage(ModelMap model){
		BookSearchCriteria bookSearchCriteria = new BookSearchCriteria(); 
		model.addAttribute("bookSearchCriteria",bookSearchCriteria);
		//bookForm.jsp
		return "searchCriteria"; 
	}
	
	
	@RequestMapping(value="searchPage.do",method = RequestMethod.POST)
	public String onSubmit(@ModelAttribute("bookSearchCriteria") BookSearchCriteria bookSearchCriteria,ModelMap model) { 
		List<Book> searchBooks=shoppingCartDao.searchBooks(bookSearchCriteria);
		model.addAttribute("searchBooks",searchBooks);	
	    return "search"; 
	}
	
	@RequestMapping(value="insertCart.do",method = RequestMethod.POST)
	public String insertCart(HttpServletRequest request,ModelMap model) { 
		
		BookSearchCriteria bookSearchCriteria = new BookSearchCriteria(); 
		model.addAttribute("bookSearchCriteria",bookSearchCriteria);
	
		String bookIds[]=request.getParameterValues("chk");
		List<String> bookIdList;
		HttpSession session=request.getSession();
		bookIdList=(List<String>)session.getAttribute("bookIdList");
		if(bookIdList==null){
			bookIdList=new ArrayList<String>();
		}
		for(String bookId : bookIds)
			bookIdList.add(bookId);
		
		session.setAttribute("bookIdList", bookIdList);
		model.addAttribute("msg","selected Item(s) is added into the shopping cart successfully!");
	    return "searchCriteria"; 
	}
	
	@RequestMapping(value="checkoutSeachedItem.do",method = RequestMethod.GET)
	public String checkoutSeachedItem(HttpServletRequest request,ModelMap model) { 
		
		List<String> bookIdList;
		HttpSession session=request.getSession();
		bookIdList=(List<String>)session.getAttribute("bookIdList");
		List<CheckoutItem> checkedoutItems=shoppingCartDao.showCheckoutItems(bookIdList);
		model.addAttribute("checkedoutItems",checkedoutItems);
	    return "checkedoutItems"; 
	}
	
	@RequestMapping(value="checkoutSeachedItem.do",method = RequestMethod.POST)
	public String insertItemIntoCart(HttpServletRequest request,ModelMap model) { 
		
		String bookIds[]=request.getParameterValues("bookId");
		String pquantity[]=request.getParameterValues("pquantity");
		List<String> bookIdList=new ArrayList<String>();
		int finalPrice=0;
		for(String bookId : bookIds)
			bookIdList.add(bookId);
		List<CheckoutItem> checkedoutItems=shoppingCartDao.showCheckoutItems(bookIdList);
		
		int index=0;
		for(CheckoutItem cot: checkedoutItems){
			  cot.setPquantity(Integer.parseInt(pquantity[index++]));
			  cot.setTotalPrice(cot.getPquantity()*cot.getPrice());
			  finalPrice+=cot.getPquantity()*cot.getPrice();
		}
		
		model.addAttribute("finalPrice",finalPrice);
		model.addAttribute("checkedoutItems",checkedoutItems);
	    return "confirmCart"; 
	}
}
