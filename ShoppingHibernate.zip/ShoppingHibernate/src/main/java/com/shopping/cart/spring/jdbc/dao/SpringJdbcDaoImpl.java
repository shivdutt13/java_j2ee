package com.shopping.cart.spring.jdbc.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.shopping.cart.hibernate.model.Customer;
import com.shopping.cart.jdbc.model.Book;
import com.shopping.cart.jdbc.model.BookCategory;
import com.shopping.cart.jdbc.model.BookId;

@Repository
public class SpringJdbcDaoImpl implements SpringJdbcDao {

	@Autowired
	@Qualifier("pdataSource")
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	public void init() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public String persistBook(Book book) {

		String query = "insert into book_tbl values(?,?,?,?,?,?,?,?,?,?)";
		jdbcTemplate.update(
				query,
				new Object[] {"BK"+getMaxId(),book.getAquantity(),book.getAuther(),
						book.getBookCategory(),book.getDescription(), book.getEdition(),
						book.getPrice(),book.getPublisher(),
						book.getQuantity(),book.getTitle(),});

		return "book is persisted!";
	}
	
	private int getMaxId(){
		String query = "select max(bookid) bookid from book_id_table";
	    BookId object=(BookId)jdbcTemplate.queryForObject(query,new BeanPropertyRowMapper(BookId.class));
	    int id=object.getBookid();
	    id++;
	    jdbcTemplate.update("update book_id_table set bookid="+id);
	    return id;
	}

	@Override
	public List<Book> findAllBook() {
		String query = "select * from book_tbl";
		List<Book> books  = jdbcTemplate.query(query,
				new BeanPropertyRowMapper(Book.class));

	    return books;

	}

	@Override
	public Book viewBook(String bookId) {
		String query = "select * from book_tbl where bookId=?";
		Book book  = jdbcTemplate.queryForObject(query,new Object[]{bookId},
				new BeanPropertyRowMapper(Book.class));

	    return book;
	}

	@Override
	public String updateBook(Book book) {
		String query = "update book_tbl set auther=?,description=?," +
				"edition=?,price=?,publisher=?,quantity=?,title=? where bookId=?";
		jdbcTemplate.update(
				query,
				new Object[] {book.getAuther(),
						book.getDescription(), book.getEdition(),
						book.getPrice(),book.getPublisher(),
						book.getQuantity(),book.getTitle(),book.getBookId()});

		return "book is update!";
	}
	
	@Override
	public String updateBookQuantity(int bookId,int aquantity) {
		String query = "update book_tbl set aquantity=? where bookId=?";
		jdbcTemplate.update(
				query,
				new Object[] {aquantity,bookId});

		return "book is update!";
	}


}
