package com.shopping.cart.spring.jdbc.dao;

import java.util.List;

import com.shopping.cart.jdbc.model.Book;
import com.shopping.cart.jdbc.model.BookCategory;

public interface SpringJdbcDao {
	
	public String  persistBook(Book book);
	
	public String  updateBook(Book book);
	
	public Book  viewBook(String bookId);
	
	public List<Book>  findAllBook();
	
	public String updateBookQuantity(int bookId,int aquantity);

}
