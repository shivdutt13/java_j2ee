package com.shopping.cart.jdbc.model;

/**
 * 
 * @author nagendra.yadav
 * This pojo will be used to store search criteria
 * for shopping cart application.
 * 
 */
public class BookSearchCriteria {

	private String categoryName;
	private String bookTitle;
	private String bookAuthor;
	private String bookPublisher;
	
	private String selectedSearchCriteria;
	

	public String getSelectedSearchCriteria() {
		return selectedSearchCriteria;
	}

	public void setSelectedSearchCriteria(String selectedSearchCriteria) {
		this.selectedSearchCriteria = selectedSearchCriteria;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookPublisher() {
		return bookPublisher;
	}

	public void setBookPublisher(String bookPublisher) {
		this.bookPublisher = bookPublisher;
	}

}
