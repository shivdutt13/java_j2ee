package com.shopping.cart.hibernate.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shopping.cart.hibernate.model.Customer;
import com.shopping.cart.hibernate.model.Lion;
import com.shopping.cart.hibernate.model.LoginForm;
import com.shopping.cart.jdbc.model.Book;
import com.shopping.cart.jdbc.model.BookSearchCriteria;
import com.shopping.cart.jdbc.model.CheckoutItem;

@Repository
@Transactional
//ShoppingCardDaoImpl shoppingCardDaoImpl=new ShoppingCardDaoImpl();
public class ShoppingCardDaoImpl  implements ShoppingCardDao{

	//<!-- this is similar to Session Factory in Hibernate -->
	//<bean id="entityManagerFactory"
	//	class="org.springframework.orm.jpa.LocalEntityManagerFactoryBean">
	//	<property name="persistenceUnitName" value="JPAShoppingCart" />
	//</bean>
	//@PersistenceContext annotation injecting entityManager from above bean
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void dummy(Lion lion) {
	   entityManager.persist(lion);
	  System.out.println("Hello");
	}

	@Override
	public LoginForm validateUser(LoginForm loginForm) {
		//HQL 
		Query query=entityManager.createQuery("from LoginForm as lf where lf.login=? and lf.password=?");
		query.setParameter(1,loginForm.getLogin());
		query.setParameter(2,loginForm.getPassword());
		List<LoginForm> list=query.getResultList();
		if(list!=null && list.size()>0){
		    return list.get(0);
		}else{
			return null;	
		}
	}

	@Override
	public Customer registerCustomer(Customer customer) {
		 
		 LoginForm loginForm=new LoginForm();
		 loginForm.setLogin(customer.getUsername());
		 loginForm.setPassword(customer.getPassword());
		 loginForm.setRole(customer.getRole());
		 entityManager.persist(customer);
		 entityManager.persist(loginForm);
		 
		 return customer;
		 
	}

	@Override
	public Customer findCustomerById(int id) {
		Customer customer=(Customer)entityManager.find(Customer.class,id);
		return customer;
	}

	@Override
	public void updateCustomer(Customer customer) {
		entityManager.merge(customer);
	}

	@Override
	public List<Customer> findAllCustomer() {
		Query query=entityManager.createNamedQuery("find.all.customer");
		List<Customer> list=query.getResultList();
		return list;
	}
	
	/**
	 * This method will return the list of searched book
	 */
	@Override
	public List<Book> searchBooks(BookSearchCriteria bookSearchCriteria) {
		String dynamicHQL="";
		Query query=null;
		if(bookSearchCriteria.getSelectedSearchCriteria().equalsIgnoreCase("Title")){
		   	dynamicHQL="from Book as book where book.title=? and book.bookCategory=? and book.aquantity>0";
		    query=entityManager.createQuery(dynamicHQL);
		    query.setParameter(1,bookSearchCriteria.getBookTitle());
		    query.setParameter(2,bookSearchCriteria.getCategoryName());
		    
		}
		if(bookSearchCriteria.getSelectedSearchCriteria().equalsIgnoreCase("Author")){
		   	dynamicHQL="from Book as book where book.auther=? and book.bookCategory=? and book.aquantity>0";
		    query=entityManager.createQuery(dynamicHQL);
		    query.setParameter(1,bookSearchCriteria.getBookAuthor());
		    query.setParameter(2,bookSearchCriteria.getCategoryName());
		
		}
		if(bookSearchCriteria.getSelectedSearchCriteria().equalsIgnoreCase("Publisher")){
		   	dynamicHQL="from Book as book where book.publisher=? and book.bookCategory=? and book.aquantity>0";
		    query=entityManager.createQuery(dynamicHQL);
		    query.setParameter(1,bookSearchCriteria.getBookPublisher());
		    query.setParameter(2,bookSearchCriteria.getCategoryName());
		
		}
		if(query!=null)
		return query.getResultList();
		else
	    return null;		
	}

	@Override
	public List<CheckoutItem> showCheckoutItems(List<String> bookIds) {
		int id=1;
		List<CheckoutItem> checkedOCheckoutItems=new ArrayList<CheckoutItem>();
		for(String bookId:bookIds){
		   Book book=(Book)entityManager.getReference(Book.class, bookId);	
		   CheckoutItem checkoutItem=new CheckoutItem();
		   checkoutItem.setId(id);
		   checkoutItem.setAquantity(book.getAquantity());
		   checkoutItem.setAuther(book.getAuther());
		   checkoutItem.setBookId(book.getBookId());
		   checkoutItem.setDescription(book.getDescription());
		   checkoutItem.setPquantity(0);
		   checkoutItem.setPrice(book.getPrice());
		   checkoutItem.setTitle(book.getTitle());
		   checkedOCheckoutItems.add(checkoutItem);
		}
		return checkedOCheckoutItems;
	}
}
