package com.shopping.cart.hibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shopping.cart.hibernate.model.Customer;
import com.shopping.cart.hibernate.model.Lion;
import com.shopping.cart.hibernate.model.LoginForm;
import com.shopping.cart.jdbc.model.BookCategory;

/**
 * 
 * @author nagendra.yadav
 *
 */


@Repository
@Transactional
public class BookCategoryDaoImpl implements BookCategoryDao {
	
	//<!-- this is similar to Session Factory in Hibernate -->
	//<bean id="entityManagerFactory"
	//	class="org.springframework.orm.jpa.LocalEntityManagerFactoryBean">
	//	<property name="persistenceUnitName" value="JPAShoppingCart" />
	//</bean>
	//@PersistenceContext annotation injecting entityManager from above bean
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public String persistBookCategory(BookCategory bookCategory) {
		  entityManager.persist(bookCategory);
		return "success";
	}

	@Override
	public String updateBookCategory(BookCategory book) {
		entityManager.merge(book);
		return "success";
	}

	@Override
	public BookCategory viewBookCategory(int bookCategoryId) {
		BookCategory bookCategory=(BookCategory)entityManager.find(BookCategory.class,bookCategoryId);
		return bookCategory;
		//return null;
	}

	@Override
	public List<BookCategory> findAllBookCategory() {
		Query query=entityManager.createQuery("from BookCategory");
		List<BookCategory> list=query.getResultList();
		return list;
	}
	//Interface for BookCategory

	@Override
	public BookCategory viewBookCategory(String cotegoryName) {
		Query query=entityManager.createQuery("from BookCategory b where b.cotegoryName='"+cotegoryName+"'");
		List<BookCategory> list=query.getResultList();
		if(list!=null && list.size()>0)
		return list.get(0);
		else{
		  return null;	
		}
		
	}

	@Override
	public void deleteBookCategoryById(BookCategory bookCategory) {
		entityManager.remove(bookCategory);
	}
}
