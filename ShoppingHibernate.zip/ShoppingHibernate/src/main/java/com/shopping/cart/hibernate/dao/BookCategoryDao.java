package com.shopping.cart.hibernate.dao;

import java.util.List;

import com.shopping.cart.hibernate.model.Customer;
import com.shopping.cart.hibernate.model.Lion;
import com.shopping.cart.hibernate.model.LoginForm;
import com.shopping.cart.jdbc.model.BookCategory;

/**
 * 
 * @author nagendra.yadav
 *
 */
public interface BookCategoryDao {
	
	//Interface for BookCategory

    public String  persistBookCategory(BookCategory book);
	
	public String  updateBookCategory(BookCategory book);
	
	public BookCategory  viewBookCategory(int bookCategoryId);
	
	public BookCategory  viewBookCategory(String cotegoryName);
	
	public List<BookCategory>  findAllBookCategory();
	
	public void  deleteBookCategoryById(BookCategory bookCategory);
	
}
