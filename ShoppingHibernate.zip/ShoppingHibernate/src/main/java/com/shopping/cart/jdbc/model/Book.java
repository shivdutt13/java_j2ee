package com.shopping.cart.jdbc.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author nagendra.yadav This is book pojo which persist book information into
 *         the database
 */

@Entity
@Table(name="book_tbl")
public class Book {

	private String bookId;
	private String auther;
	private String title;
	private String edition;
	private String publisher;
	private int price;
	private int quantity;
	private String description;
	
	private int aquantity;
	
	private String bookCategory;
	
	

	public String getBookCategory() {
		return bookCategory;
	}

	public void setBookCategory(String bookCategory) {
		this.bookCategory = bookCategory;
	}

	public int getAquantity() {
		return aquantity;
	}

	public void setAquantity(int aquantity) {
		this.aquantity = aquantity;
	}

	public Book() {

	}

	public Book(String bookId, String auther, String title, String edition,
			String publisher, int price, int quantity, String description) {
		super();
		this.bookId = bookId;
		this.auther = auther;
		this.title = title;
		this.edition = edition;
		this.publisher = publisher;
		this.price = price;
		this.quantity = quantity;
		this.description = description;
	}

	@Id
	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getAuther() {
		return auther;
	}

	public void setAuther(String auther) {
		this.auther = auther;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
	  return "bookId = "+bookId+" , title ="+title +", auther = "+auther;
	}

}
