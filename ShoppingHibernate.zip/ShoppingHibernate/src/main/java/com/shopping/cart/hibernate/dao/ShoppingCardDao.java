package com.shopping.cart.hibernate.dao;

import java.util.List;

import com.shopping.cart.hibernate.model.Customer;
import com.shopping.cart.hibernate.model.Lion;
import com.shopping.cart.hibernate.model.LoginForm;
import com.shopping.cart.jdbc.model.Book;
import com.shopping.cart.jdbc.model.BookSearchCriteria;
import com.shopping.cart.jdbc.model.CheckoutItem;

/**
 * 
 * @author nagendra.yadav
 *
 */
public interface ShoppingCardDao {
	
	public void dummy(Lion lion);
	
	public LoginForm validateUser(LoginForm loginForm);
	
	public Customer registerCustomer(Customer customer);
	
	public Customer findCustomerById(int id);
	
	public List<Customer> findAllCustomer();
	
	public void updateCustomer(Customer customer);
	
	public List<Book> searchBooks(BookSearchCriteria bookSearchCriteria);
	
	public List<CheckoutItem> showCheckoutItems(List<String> bookIds);
	
}
