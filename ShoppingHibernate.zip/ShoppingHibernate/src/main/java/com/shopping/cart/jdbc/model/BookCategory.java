package com.shopping.cart.jdbc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book_category_tbl")
public class BookCategory {

	private int bookCategoryId;
	private String cotegoryName;
	private String description;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getBookCategoryId() {
		return bookCategoryId;
	}

	public void setBookCategoryId(int bookCategoryId) {
		this.bookCategoryId = bookCategoryId;
	}

	public String getCotegoryName() {
		return cotegoryName;
	}

	public void setCotegoryName(String cotegoryName) {
		this.cotegoryName = cotegoryName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
